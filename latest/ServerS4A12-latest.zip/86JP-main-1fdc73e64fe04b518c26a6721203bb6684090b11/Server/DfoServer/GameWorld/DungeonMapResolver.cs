using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using PvfLib;

namespace DfoServer.GameWorld
{
    internal enum MapFileType : byte
    {
        Normal,
        Start,
        Boss,
        Named,
        End,
        Hidden,
        Quest,
        Default,
    }

    internal struct MapFileEntry
    {
        public int MapId;
        public MapFileType FileType;
        public bool HasCoordinate;
        public int CoordX;
        public int CoordY;
    }

    internal sealed class DungeonMapDirectoryIndex
    {
        public Dictionary<long, List<MapFileEntry>> ByCoordinate { get; } = new Dictionary<long, List<MapFileEntry>>();
        public Dictionary<MapFileType, List<MapFileEntry>> ByType { get; } = new Dictionary<MapFileType, List<MapFileEntry>>();

        public static long CoordKey(int x, int y) => ((long)x << 32) | (uint)y;

        public void Add(MapFileEntry entry)
        {
            if (entry.HasCoordinate)
            {
                var key = CoordKey(entry.CoordX, entry.CoordY);
                if (!ByCoordinate.TryGetValue(key, out var list))
                {
                    list = new List<MapFileEntry>();
                    ByCoordinate[key] = list;
                }
                list.Add(entry);
            }

            if (!ByType.TryGetValue(entry.FileType, out var typeList))
            {
                typeList = new List<MapFileEntry>();
                ByType[entry.FileType] = typeList;
            }
            typeList.Add(entry);
        }
    }

    internal static class DungeonMapResolver
    {
        private static readonly Regex MapCoordinateFileNameRegex =
            new Regex(@"\((?<x>-?\d+)[,.](?<y>-?\d+)\)", RegexOptions.Compiled);

        private static readonly ConcurrentDictionary<int, bool> BossActorMapCache =
            new ConcurrentDictionary<int, bool>();

        private static readonly ConcurrentDictionary<int, HashSet<int>>
            MapMonsterCodeCache =
                new ConcurrentDictionary<int, HashSet<int>>();

        private static readonly ConcurrentDictionary<int, DungeonMapDirectoryIndex> DirIndexCache =
            new ConcurrentDictionary<int, DungeonMapDirectoryIndex>();

        internal static int ResolveMapId(int dungeonId, int x, int y, MazeInfo maze, int mazeIndex, int[] bossPos)
        {
            var maplst = Dungeon.LoadLstFile(Path.Combine("map", "map.lst"));
            var loaded = Dungeon.LoadDungeonFileWithPath(dungeonId);
            var mapDirCandidates = Dungeon.BuildMapDirCandidates(maplst, maze, loaded.FilePath);

            var effectiveBoss = bossPos ?? (maze.BossMap != null && maze.BossMap.Length >= 2
                ? new[] { maze.BossMap[0], maze.BossMap[1] } : null);

            bool isStartRoom = maze.StartMap != null && maze.StartMap.Length >= 2
                               && maze.StartMap[0] == x && maze.StartMap[1] == y;
            bool isBossRoom = effectiveBoss != null && effectiveBoss[0] == x && effectiveBoss[1] == y;
            bool isQuestConnected = maze.QuestConnection != null && maze.QuestConnection.Length >= 2;

            var index = GetOrBuildIndex(dungeonId, maplst, mapDirCandidates);

            // For non-quest start/boss rooms, a typed directory file at the exact
            // coordinate takes priority over generic MapSpecification (the start/boss
            // variant has different NPCs/layout from the ordinary "map" type spec).
            // Quest-connected mazes skip this — their MapSpecification is authoritative.
            if (!isQuestConnected && (isStartRoom || isBossRoom))
            {
                var key = DungeonMapDirectoryIndex.CoordKey(x, y);
                if (index.ByCoordinate.TryGetValue(key, out var typed))
                {
                    var preferType = isBossRoom ? MapFileType.Boss : MapFileType.Start;
                    var hit = PickByType(typed, preferType);
                    if (hit > 0) return hit;
                }
            }

            // Step 1: MapSpecification
            int mapId = ResolveFromMapSpecification(maplst, maze, x, y, isBossRoom);
            if (mapId > 0)
                return mapId;

            // Step 2+3: Directory index (coordinate + type pool)
            mapId = ResolveFromDirectoryIndex(index, x, y, isStartRoom, isBossRoom, isQuestConnected);
            if (mapId > 0)
                return mapId;

            FileLogger.Log($"[DungeonMapResolver] UNRESOLVED: dungeon={dungeonId} maze={mazeIndex} room=({x},{y}) start={isStartRoom} boss={isBossRoom} quest={isQuestConnected} dirEntries={CountIndexEntries(index)}");
            return -1;
        }

        internal static bool HasExplicitBossCandidatePool(
            MazeInfo maze,
            int x,
            int y)
        {
            if (maze?.MapSpecifications == null)
                return false;

            foreach (var item in maze.MapSpecifications)
            {
                if (item.X != x
                    || item.Y != y
                    || (!string.Equals(
                            item.Type,
                            "boss",
                            StringComparison.OrdinalIgnoreCase)
                        && !string.Equals(
                            item.Type,
                            "map",
                            StringComparison.OrdinalIgnoreCase)))
                {
                    continue;
                }

                if (item.MapCandidates != null
                    && item.MapCandidates.Length > 1)
                {
                    return true;
                }
            }

            return false;
        }

        internal static List<int> GetExplicitBossCandidateMapIds(
            MazeInfo maze,
            int x,
            int y)
        {
            var result = new List<int>();
            var seen = new HashSet<int>();
            if (maze?.MapSpecifications == null)
                return result;

            foreach (var item in maze.MapSpecifications)
            {
                if (item.X != x
                    || item.Y != y
                    || (!string.Equals(
                            item.Type,
                            "boss",
                            StringComparison.OrdinalIgnoreCase)
                        && !string.Equals(
                            item.Type,
                            "map",
                            StringComparison.OrdinalIgnoreCase)))
                {
                    continue;
                }

                var candidates = item.MapCandidates != null
                    && item.MapCandidates.Length > 0
                        ? item.MapCandidates
                        : new[] { item.Index };
                foreach (var mapId in candidates)
                {
                    if (mapId > 0 && seen.Add(mapId))
                        result.Add(mapId);
                }
            }

            return result;
        }

        internal static int ResolveExplicitBossCandidateMapId(
            MazeInfo maze,
            int x,
            int y)
        {
            if (!HasExplicitBossCandidatePool(maze, x, y))
                return -1;

            var maplst = Dungeon.LoadLstFile(Path.Combine("map", "map.lst"));
            return ResolveFromMapSpecification(
                maplst,
                maze,
                x,
                y,
                isBossRoom: true);
        }

        internal static bool MapContainsMonsterCode(
            int mapId,
            int monsterCode)
        {
            if (mapId <= 0 || monsterCode <= 0)
                return false;

            try
            {
                return MapMonsterCodeCache
                    .GetOrAdd(mapId, LoadMapMonsterCodes)
                    .Contains(monsterCode);
            }
            catch (Exception ex)
            {
                FileLogger.Log(
                    $"[DungeonMapResolver] quest target inspection failed: " +
                    $"map={mapId} monster={monsterCode} error={ex.Message}");
                return false;
            }
        }

        // --- Step 1: MapSpecification ---

        private static int ResolveFromMapSpecification(LstFile maplst, MazeInfo maze, int x, int y, bool isBossRoom)
        {
            if (maze.MapSpecifications == null || maze.MapSpecifications.Count == 0)
                return -1;

            if (isBossRoom)
            {
                var bossActorMapIds = new List<int>();
                int[] firstCandidates = null;

                foreach (var item in maze.MapSpecifications)
                {
                    if (item.X != x || item.Y != y) continue;
                    var specType = item.Type ?? string.Empty;
                    if (!string.Equals(specType, "boss", StringComparison.OrdinalIgnoreCase)
                        && !string.Equals(specType, "map", StringComparison.OrdinalIgnoreCase))
                        continue;

                    var candidates = item.MapCandidates != null && item.MapCandidates.Length > 0
                        ? item.MapCandidates
                        : new[] { item.Index };
                    if (firstCandidates == null)
                        firstCandidates = candidates;

                    foreach (var cid in candidates)
                    {
                        if (cid > 0 && HasBossActor(maplst, cid))
                            bossActorMapIds.Add(cid);
                    }
                }

                if (bossActorMapIds.Count > 0)
                    return bossActorMapIds.Count > 1
                        ? bossActorMapIds[Infrastructure.ServerRandom.Next(bossActorMapIds.Count)]
                        : bossActorMapIds[0];
                if (firstCandidates != null && firstCandidates.Length > 0)
                    return firstCandidates.Length > 1
                        ? firstCandidates[Infrastructure.ServerRandom.Next(firstCandidates.Length)]
                        : firstCandidates[0];
            }

            foreach (var item in maze.MapSpecifications)
            {
                if (item.X != x || item.Y != y) continue;
                if (string.Equals(item.Type, "boss", StringComparison.OrdinalIgnoreCase)) continue;
                if (item.MapCandidates != null && item.MapCandidates.Length > 1)
                    return item.MapCandidates[Infrastructure.ServerRandom.Next(item.MapCandidates.Length)];
                return item.Index;
            }

            return -1;
        }

        // --- Step 2+3: Directory Index ---

        private static int ResolveFromDirectoryIndex(
            DungeonMapDirectoryIndex index, int x, int y,
            bool isStartRoom, bool isBossRoom, bool isQuestConnected)
        {
            // Step 2: Coordinate lookup
            var key = DungeonMapDirectoryIndex.CoordKey(x, y);
            if (index.ByCoordinate.TryGetValue(key, out var coordEntries) && coordEntries.Count > 0)
            {
                // Quest preference
                if (isQuestConnected)
                {
                    var questHit = PickByType(coordEntries, MapFileType.Quest);
                    if (questHit > 0) return questHit;
                }

                // Type preference
                if (isStartRoom)
                {
                    var startHit = PickByType(coordEntries, MapFileType.Start);
                    if (startHit > 0) return startHit;
                }
                if (isBossRoom)
                {
                    var bossHit = PickByType(coordEntries, MapFileType.Boss);
                    if (bossHit > 0) return bossHit;
                }

                // Normal or any
                var normalHit = PickByType(coordEntries, MapFileType.Normal);
                if (normalHit > 0) return normalHit;

                // Any coordinate match
                return coordEntries[coordEntries.Count > 1
                    ? Infrastructure.ServerRandom.Next(coordEntries.Count) : 0].MapId;
            }

            // Step 3: Type-pool lookup (files without coordinates)
            if (isQuestConnected)
            {
                var questPool = PickFromPool(index, MapFileType.Quest);
                if (questPool > 0) return questPool;
            }
            if (isStartRoom)
            {
                var startPool = PickFromPool(index, MapFileType.Start);
                if (startPool > 0) return startPool;
            }
            if (isBossRoom)
            {
                var bossPool = PickFromPool(index, MapFileType.Boss);
                if (bossPool > 0) return bossPool;
            }

            var normalPool = PickFromPool(index, MapFileType.Normal);
            if (normalPool > 0) return normalPool;

            return -1;
        }

        private static int PickByType(List<MapFileEntry> entries, MapFileType type)
        {
            var candidates = new List<int>();
            foreach (var e in entries)
                if (e.FileType == type) candidates.Add(e.MapId);
            if (candidates.Count == 0) return -1;
            return candidates.Count > 1
                ? candidates[Infrastructure.ServerRandom.Next(candidates.Count)]
                : candidates[0];
        }

        private static int PickFromPool(DungeonMapDirectoryIndex index, MapFileType type)
        {
            if (!index.ByType.TryGetValue(type, out var pool) || pool.Count == 0)
                return -1;
            // Only pick from entries WITHOUT coordinates (pure type-pool files)
            var noCoord = new List<int>();
            foreach (var e in pool)
                if (!e.HasCoordinate) noCoord.Add(e.MapId);
            if (noCoord.Count == 0) return -1;
            return noCoord.Count > 1
                ? noCoord[Infrastructure.ServerRandom.Next(noCoord.Count)]
                : noCoord[0];
        }

        // --- Index building ---

        private static DungeonMapDirectoryIndex GetOrBuildIndex(int dungeonId, LstFile maplst, List<string> mapDirCandidates)
        {
            return DirIndexCache.GetOrAdd(dungeonId, _ => BuildIndex(maplst, mapDirCandidates));
        }

        internal static DungeonMapDirectoryIndex BuildIndex(LstFile maplst, IReadOnlyList<string> mapDirCandidates)
        {
            var index = new DungeonMapDirectoryIndex();
            if (maplst == null) return index;

            foreach (var entry in maplst.Entries)
            {
                if (entry == null || string.IsNullOrEmpty(entry.FilePath))
                    continue;
                if (!InMapDirCandidate(entry.FilePath, mapDirCandidates))
                    continue;

                var fileName = Path.GetFileName(entry.FilePath);
                var stem = Path.GetFileNameWithoutExtension(fileName) ?? string.Empty;

                var fileType = ClassifyFileType(stem);
                TryParseMapFileCoordinate(fileName, out var hasCoord, out var cx, out var cy);

                index.Add(new MapFileEntry
                {
                    MapId = entry.Id,
                    FileType = fileType,
                    HasCoordinate = hasCoord,
                    CoordX = cx,
                    CoordY = cy,
                });
            }

            return index;
        }

        internal static MapFileType ClassifyFileType(string stem)
        {
            if (string.IsNullOrEmpty(stem))
                return MapFileType.Normal;

            // Strip coordinate pattern like "(0,0)" to isolate prefix+suffix
            var typeStr = MapCoordinateFileNameRegex.Replace(stem, "").Trim();
            if (typeStr != stem)
            {
                // Had coordinate; check suffix after stripping digits
                var lower = typeStr.ToLowerInvariant();
                // Strip leading digits to get pure type suffix: "20start" → "start", "77001b" → "b"
                int suffixStart = 0;
                while (suffixStart < lower.Length && char.IsDigit(lower[suffixStart])) suffixStart++;
                var suffix = suffixStart < lower.Length ? lower.Substring(suffixStart) : "";
                // Also check prefix (before coordinate): "s407(4,0)" → prefix "s407" → starts with 's'
                int prefixEnd = 0;
                while (prefixEnd < lower.Length && (char.IsDigit(lower[prefixEnd]) || char.IsLetter(lower[prefixEnd]))) prefixEnd++;
                var prefix = lower.Substring(0, Math.Min(prefixEnd, suffixStart));

                if (suffix.Contains("start") || suffix == "s" || prefix.StartsWith("s")) return MapFileType.Start;
                if (suffix.Contains("boss") || suffix == "b" || prefix.StartsWith("b")) return MapFileType.Boss;
                if (suffix.Contains("normal") || suffix == "n" || prefix.StartsWith("n")) return MapFileType.Normal;
                if (suffix.Contains("quest") || suffix.StartsWith("q") || prefix.StartsWith("q")) return MapFileType.Quest;
                if (prefix.StartsWith("h")) return MapFileType.Hidden;
                if (prefix.StartsWith("e")) return MapFileType.End;
                if (prefix.StartsWith("d")) return MapFileType.Default;
                if (prefix.StartsWith("bn")) return MapFileType.Named;
                return MapFileType.Normal;
            }

            // No coordinate in filename — classify by prefix
            var stemLower = stem.ToLowerInvariant();

            if (stemLower.StartsWith("q_") || stemLower.StartsWith("quest"))
                return MapFileType.Quest;
            if (stemLower.Length > 1 && stemLower[0] == 'q' && char.IsDigit(stemLower[1]))
                return MapFileType.Quest;

            if (stemLower.StartsWith("bn") && stemLower.Length > 2 && char.IsDigit(stemLower[2]))
                return MapFileType.Named;

            if (stemLower.Contains("boss"))
                return MapFileType.Boss;
            if (stemLower.StartsWith("b") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.Boss;
            // Lowercase trailing 'b' after digit or ')' for coordinate-encoded boss files like "77001(2,4)b"
            if (stemLower.Length >= 2 && stemLower[stemLower.Length - 1] == 'b')
            {
                var prev = stemLower[stemLower.Length - 2];
                if (char.IsDigit(prev) || prev == ')') return MapFileType.Boss;
            }

            if (stemLower.Contains("start"))
                return MapFileType.Start;
            if (stemLower.StartsWith("s") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.Start;
            // Trailing 'S' after digit
            if (stemLower.Length >= 2 && stem[stem.Length - 1] == 'S')
            {
                var prev = stemLower[stemLower.Length - 2];
                if (char.IsDigit(prev) || prev == ')') return MapFileType.Start;
            }

            if (stemLower.StartsWith("e") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.End;

            if (stemLower.StartsWith("h") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.Hidden;

            if (stemLower.StartsWith("d") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.Default;

            if (stemLower.StartsWith("n") && stemLower.Length > 1 && char.IsDigit(stemLower[1]))
                return MapFileType.Normal;
            if (stemLower.Contains("normal"))
                return MapFileType.Normal;
            // Trailing 'N' after digit
            if (stemLower.Length >= 2 && stem[stem.Length - 1] == 'N')
            {
                var prev = stemLower[stemLower.Length - 2];
                if (char.IsDigit(prev) || prev == ')') return MapFileType.Normal;
            }

            // Pure numeric stem
            bool allDigit = true;
            for (int i = 0; i < stemLower.Length; i++)
                if (!char.IsDigit(stemLower[i])) { allDigit = false; break; }
            if (allDigit && stemLower.Length > 0) return MapFileType.Normal;

            // Unrecognized — treat as Normal
            return MapFileType.Normal;
        }

        internal static void TryParseMapFileCoordinate(string fileName, out bool found, out int x, out int y)
        {
            found = false;
            x = 0;
            y = 0;
            if (string.IsNullOrEmpty(fileName)) return;
            var stem = Path.GetFileNameWithoutExtension(fileName) ?? string.Empty;
            var match = MapCoordinateFileNameRegex.Match(stem);
            if (match.Success && int.TryParse(match.Groups["x"].Value, out x) && int.TryParse(match.Groups["y"].Value, out y))
                found = true;
        }

        // kept for old selftest compatibility
        internal static bool TryParseMapFileCoordinate(string fileName, out int x, out int y)
        {
            TryParseMapFileCoordinate(fileName, out var found, out x, out y);
            return found;
        }

        // --- Boss actor verification (for MapSpecification step) ---

        private static bool HasBossActor(LstFile maplst, int mapId)
        {
            if (maplst == null || mapId <= 0) return false;
            if (BossActorMapCache.TryGetValue(mapId, out var cached))
                return cached;

            var found = false;
            try
            {
                var mapFilePath = Dungeon.ResolveFilePath(maplst, mapId, "map");
                var mapFile = MapFile.Parse(PvfArchiveAccessor.ReadText(Path.Combine("map", mapFilePath)));
                foreach (var monster in mapFile.Monsters)
                {
                    if (monster.MonsterId.GetValueOrDefault() > 0 && monster.Type == MonsterType.Boss)
                    { found = true; break; }
                }
                if (!found)
                {
                    foreach (var apc in mapFile.AICharacters)
                    {
                        if (apc.Code > 0 && apc.AIType == ApcAIType.Boss)
                        { found = true; break; }
                    }
                }
            }
            catch { }
            BossActorMapCache[mapId] = found;
            return found;
        }

        private static HashSet<int> LoadMapMonsterCodes(int mapId)
        {
            var result = new HashSet<int>();
            var maplst = Dungeon.LoadLstFile(Path.Combine("map", "map.lst"));
            var mapFilePath = Dungeon.ResolveFilePath(maplst, mapId, "map");
            var mapFile = MapFile.Parse(
                PvfArchiveAccessor.ReadText(Path.Combine("map", mapFilePath)));

            AddMonsterCodes(result, mapFile.Monsters);
            AddMonsterCodes(result, mapFile.MonsterConditionMonsters);
            AddMonsterCodes(result, mapFile.ConditionalSummonMonsters);

            foreach (var apc in mapFile.AICharacters)
            {
                if (apc.Code > 0)
                    result.Add(apc.Code);
            }

            foreach (var obj in mapFile.SpecialPassiveObjects)
            {
                if (obj?.Spawns == null)
                    continue;

                foreach (var spawn in obj.Spawns)
                {
                    if (spawn.Code > 0)
                        result.Add(spawn.Code);
                }
            }

            return result;
        }

        private static void AddMonsterCodes(
            HashSet<int> result,
            IReadOnlyList<MonsterInfo> monsters)
        {
            if (result == null || monsters == null)
                return;

            foreach (var monster in monsters)
            {
                var code = monster?.MonsterId.GetValueOrDefault() ?? 0;
                if (code > 0)
                    result.Add(code);
            }
        }

        // --- Helpers ---

        private static bool InMapDirCandidate(string filePath, IReadOnlyList<string> mapDirCandidates)
        {
            if (string.IsNullOrEmpty(filePath)) return false;
            if (mapDirCandidates == null || mapDirCandidates.Count == 0) return true;

            var normalizedPath = filePath.Replace('\\', '/');
            for (var i = 0; i < mapDirCandidates.Count; i++)
            {
                var dir = mapDirCandidates[i];
                if (string.IsNullOrEmpty(dir)) continue;
                dir = dir.Replace('\\', '/').TrimEnd('/');
                if (normalizedPath.Equals(dir, StringComparison.OrdinalIgnoreCase)
                    || normalizedPath.StartsWith(dir + "/", StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        internal static bool IsQuestVariantFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return false;
            var stem = Path.GetFileNameWithoutExtension(fileName) ?? string.Empty;
            return stem.StartsWith("q_", StringComparison.OrdinalIgnoreCase)
                || stem.StartsWith("quest_", StringComparison.OrdinalIgnoreCase)
                || (stem.Length > 1
                    && char.ToLowerInvariant(stem[0]) == 'q'
                    && char.IsDigit(stem[1]));
        }

        internal static bool IsBossVariantFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return false;
            var stem = Path.GetFileNameWithoutExtension(fileName) ?? string.Empty;
            if (stem.IndexOf("boss", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (stem.EndsWith("B", StringComparison.OrdinalIgnoreCase))
            {
                var prev = stem.Length >= 2 ? stem[stem.Length - 2] : '\0';
                return char.IsDigit(prev) || prev == ')';
            }
            return false;
        }

        private static int CountIndexEntries(DungeonMapDirectoryIndex index)
        {
            int count = 0;
            foreach (var kv in index.ByType)
                count += kv.Value.Count;
            return count;
        }

        // --- Backward-compatible fallback API for selftests ---

        internal static int SelectFallbackMapIdForUnresolvedRoom(
            int dungeonId, int mazeIndex, int x, int y,
            IReadOnlyList<MapSpecificationItem> mapSpecifications,
            IReadOnlyList<LstEntry> mapEntries,
            IReadOnlyList<string> mapDirCandidates,
            bool preferQuestVariant,
            out string reason)
        {
            reason = string.Empty;

            // Build a temporary index from the provided entries
            var maplst = new LstFile();
            if (mapEntries != null)
                foreach (var e in mapEntries)
                    if (e != null) maplst.Entries.Add(e);

            var index = BuildIndex(maplst, mapDirCandidates as List<string> ?? new List<string>(mapDirCandidates ?? Array.Empty<string>()));

            // Quest variant preference
            if (preferQuestVariant)
            {
                var key = DungeonMapDirectoryIndex.CoordKey(x, y);
                if (index.ByCoordinate.TryGetValue(key, out var coordEntries))
                {
                    var questHit = PickByType(coordEntries, MapFileType.Quest);
                    if (questHit > 0) { reason = "quest-variant coordinate map"; return questHit; }
                }
                // Any quest file
                if (index.ByType.TryGetValue(MapFileType.Quest, out var questPool))
                {
                    foreach (var e in questPool)
                    {
                        if (e.MapId > 0) { reason = "quest-variant map"; return e.MapId; }
                    }
                }
            }

            // Coordinate-based lookup (nearest coordinate, not just exact)
            var bestId = -1;
            var bestDistance = int.MaxValue;
            var bestX = 0;
            var bestY = 0;
            foreach (var kv in index.ByCoordinate)
            {
                foreach (var entry in kv.Value)
                {
                    if (entry.FileType == MapFileType.Boss) continue;
                    if (entry.FileType == MapFileType.Quest && !preferQuestVariant) continue;
                    var dist = Math.Abs(entry.CoordX - x) + Math.Abs(entry.CoordY - y);
                    if (dist < bestDistance || (dist == bestDistance && entry.MapId < bestId))
                    {
                        bestDistance = dist;
                        bestId = entry.MapId;
                        bestX = entry.CoordX;
                        bestY = entry.CoordY;
                    }
                }
            }
            if (bestId > 0) { reason = $"nearest coordinate map ({bestX},{bestY})"; return bestId; }

            // First map spec
            if (mapSpecifications != null)
            {
                foreach (var item in mapSpecifications)
                {
                    if (item == null || item.Index <= 0) continue;
                    reason = "first map spec";
                    if (item.MapCandidates != null && item.MapCandidates.Length > 0)
                        return item.MapCandidates[Infrastructure.ServerRandom.Next(item.MapCandidates.Length)];
                    return item.Index;
                }
            }

            // First non-quest candidate
            if (index.ByType.TryGetValue(MapFileType.Normal, out var normalPool) && normalPool.Count > 0)
            {
                reason = "first non-quest candidate map";
                return normalPool[0].MapId;
            }

            return -1;
        }
    }
}
