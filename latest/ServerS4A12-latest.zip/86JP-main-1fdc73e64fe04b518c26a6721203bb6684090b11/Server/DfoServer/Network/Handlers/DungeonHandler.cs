using DfoServer.Game.Inventory;
using DfoServer.Game.SelectCharacter;
using DfoServer.Network.Builders;
using DfoServer.Network.Handlers.Dungeon;
using System;
using System.Threading.Tasks;

namespace DfoServer.Network.Handlers
{
    public sealed class DungeonHandler
    {
        public string ProtocolName => "GameProtocol";

        private readonly DungeonSharedServices _services;
        private readonly DungeonEntryHandler _entry;
        private readonly DungeonMapHandler _map;
        private readonly DungeonCombatHandler _combat;
        private readonly DungeonSettlementHandler _settlement;
        private readonly DungeonTutorialHandler _tutorial;

        public DungeonHandler(
            IAssetService assetService,
            Game.ReviveCoin.ReviveCoinService reviveCoinService,
            Game.Characters.SqliteCharacterRepository characterRepository,
            SqliteSelectCharacterDataSource selectCharacterDataSource,
            IRentalTimeProvider rentalTimeProvider,
            IInventoryStore inventoryStore,
            InventoryRefreshSender inventoryRefresh,
            Game.Party.PartyManager partyManager = null,
            Game.Session.ISessionDirectory sessionDirectory = null,
            Game.Quests.QuestDropService questDropService = null,
            Game.Accounts.AccountExperienceProgressService accountExperience = null)
        {
            _services = new DungeonSharedServices(
                assetService,
                reviveCoinService,
                characterRepository,
                selectCharacterDataSource,
                rentalTimeProvider,
                inventoryStore,
                inventoryRefresh,
                partyManager,
                sessionDirectory,
                questDropService,
                accountExperience);
            _settlement = new DungeonSettlementHandler(_services);
            _map = new DungeonMapHandler(_services);
            _entry = new DungeonEntryHandler(_services, _map);
            _combat = new DungeonCombatHandler(_services, _settlement);
            _tutorial = new DungeonTutorialHandler(_services, _settlement);
        }

        public static Task ResetDungeonStateAsync(EnhancedClientSession session)
            => Dungeon.DungeonRunLifecycle.EndRunToTownAsync(session);

        public Task Handle_ENUM_CMDPACKET_ENTER_SELECT_DUNGEON(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _entry.HandleEnterSelectDungeon(session, header, body);

        public Task Handle_ENUM_CMDPACKET_SELECT_DUNGEON(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _entry.HandleSelectDungeon(session, header, body);

        public Task Handle_ENUM_CMDPACKET_GORGEOUS_CHALLENGE_TOGGLE(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _entry.HandleGorgeousChallengeToggle(session, header, body);

        public Task Handle_ENUM_CMDPACKET_MOVE_MAP(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _map.HandleMoveMap(session, header, body);

        public Task Handle_ENUM_CMDPACKET_HELLPARTY_START(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _map.HandleHellPartyStart(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DIE_MONSTER(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleDieMonster(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DIE_CHARACTER(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleDieCharacter(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DEATH_RESPAWN(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleDeathRespawn(session, header, body);

        public Task Handle_ENUM_CMDPACKET_USE_COIN(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleUseCoin(session, header, body);

        public Task Handle_ENUM_CMDPACKET_GET_ITEM(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleGetItem(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DROP_ITEM(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleDropItem(session, header, body);

        public Task Handle_BOSS_DIE_CHECK(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _combat.HandleBossDieCheck(session, header, body);

        public Task Handle_ENUM_CMDPACKET_SELECT_CARD(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _settlement.HandleSelectCard(session, header, body);

        public Task Handle_ENUM_CMDPACKET_EPLP_COMMAND(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _settlement.HandleEplpCommand(session, header, body);

        public Task Handle_CARD_START_REQUEST(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _settlement.HandleCardStartRequest(session, header, body);

        public Task Handle_SET_PLAY_RESULT(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _settlement.HandleSetPlayResult(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DUNGEON_EVENT_STORY_PAUSE(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _tutorial.HandleStoryPause(session, header, body);

        public Task Handle_ENUM_CMDPACKET_CHANGE_TUTORIAL_FLAG(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _tutorial.HandleChangeTutorialFlag(session, header, body);

        public Task Handle_ENUM_CMDPACKET_TUTORIAL_LEVEL_UP(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _tutorial.HandleTutorialLevelUp(session, header, body);

        public Task Handle_BACK_2_VILLAGE(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _tutorial.HandleBack2Village(session, header, body);

        public Task Handle_ENUM_CMDPACKET_DEATH_TOWER_STAGE_CMD(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _services.DeathTower.HandleStageCommand(session, header, body);

        public Task<bool> TryHandleDeathTowerUseStackable(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _services.DeathTower.TryHandleUseStackable(session, header, body);

        public Task<bool> TryHandleDeathTowerMoveItem(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => _services.DeathTower.TryHandleMoveItem(session, header, body);

        public Task Handle_SPECIAL_SUMMON_MONSTER(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => Dungeon.SpecialDungeonNotifier.HandleBossSummonRequestAsync(session, header, body);

        public Task Handle_SPECIAL_TIMER_MODIFY_INFO(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => Dungeon.SpecialDungeonNotifier.HandleGentInfiltrateTimerModifyInfoAsync(session, header, body);

        public Task Handle_SPECIAL_SEA_CHASE_RESULT(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => Dungeon.SpecialDungeonNotifier.HandleSeaChaseMiniGameResultAsync(session, header, body);

        public Task Handle_SPECIAL_SEA_CHASE_OBSERVE(EnhancedClientSession session, GamePacketHeader header, byte[] body)
            => Dungeon.SpecialDungeonNotifier.ObserveSeaChasePacketAsync(session, header, body);

        public Task HandleDungeonSceneUniqueIdReport(EnhancedClientSession session, GamePacketHeader header, byte[] body)
        {
            if (session?.Player != null && body != null && body.Length >= 2)
            {
                var raw = body.Length >= 4
                    ? BitConverter.ToUInt32(body, 0)
                    : BitConverter.ToUInt16(body, 0);
                var sceneUniqueId = (ushort)(raw & 0xFFFF);

                if (sceneUniqueId != 0)
                {
                    session.Player.DungeonSceneUniqueId = sceneUniqueId;
                    FileLogger.Log($"[DungeonHandler] DUNGEON_SCENE_UID: cid={session.Player.CharacterId} baseUid={session.Player.UserId} sceneUid={sceneUniqueId} raw=0x{raw:X8} body={BitConverter.ToString(body)}");
                }
                else
                {
                    FileLogger.Log($"[DungeonHandler] DUNGEON_SCENE_UID: ignored zero cid={session.Player.CharacterId} baseUid={session.Player.UserId} body={BitConverter.ToString(body)}");
                }
            }

            return session.SendPacketAsync(GamePacketEnvelopeBuilder.Build(0x01, 0x01DE, CommonPacketBodyBuilder.BuildSuccessAck()));
        }
    }
}
