﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DfoServer.Game.Session;
using DfoServer.Game.Accounts;

namespace DfoServer.Network
{
    public class EnhancedClientSession
    {
        public Guid SessionId { get; } = Guid.NewGuid();
        public TcpClient TcpClient { get; }
        public NetworkStream Stream => TcpClient.GetStream();
        public DateTime ConnectedTime { get; } = DateTime.Now;
        public IPacketHeader PacketStructure { get; private set; }
        public ushort SequenceNumber { get; private set; }

        
        
        
        
        public PlayerContext Player { get; } = new PlayerContext();

        
        
        
        public AccountRecord Account { get; set; }

        public GameSession GameSession { get; set; }

        // 玩家当前打开的收集箱 PVF [Index] 值(0388请求体末尾字节, 见 CollectionBoxHandler)
        public int SelectedCollectionBoxIndex { get; set; }

        public int PendingDarkKnightAutoComboCharacterId { get; set; }

        public DateTime PendingDarkKnightAutoComboUtc { get; set; }

        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);

        public EnhancedClientSession(TcpClient client, IPacketHeader packetStructure)
        {
            TcpClient = client;
            PacketStructure = packetStructure;
            SequenceNumber = 0;
        }

        public async Task SendPacketAsync(byte[] data)
        {
            PacketFileLogger.Log("SEND", data);
            await _sendLock.WaitAsync();
            try
            {
                await Stream.WriteAsync(data, 0, data.Length);
            }
            finally
            {
                _sendLock.Release();
            }
        }

        public void Close()
        {
            TcpClient?.Close();
            _sendLock.Dispose();
        }
    }
}
